﻿using Microsoft.AspNetCore.Mvc;
using NuestraApi.Data;
using NuestraApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NuestraApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SerieController : ControllerBase
    {
        private DataContext DataContext { get; set; }

        public SerieController(DataContext DataContext)
        {
            this.DataContext = DataContext;
        }

        // GET: api/<MovieController>
        [HttpGet]
        public List<Serie> GetAllSeries()
        {
            var service = new SerieService(dataContext);
            var series = service.GetAllSeries();
            return series;
        }
        // GET: api/<MovieController>
        [HttpGet("Series")]
        public void PopulateAlbums()
        {
            var service = new PopulateServices(DataContext);
            service.FillDataSerie();
        }
    }
}
